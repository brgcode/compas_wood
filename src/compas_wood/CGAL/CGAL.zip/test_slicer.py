import os
import numpy as np

from compas.geometry import Point
from compas.geometry import Vector
from compas.geometry import Plane
from compas.geometry import Polyline
from compas.datastructures import Mesh

from compas_wood import HERE #?
from compas_wood.CGAL import slicer

def test_slicer():

    print("Start")
    FILE = os.path.join(HERE,  'data', '3DBenchy.stl')#'../..',


    # ==============================================================================
    # Get benchy and construct a mesh
    # ==============================================================================

    benchy = Mesh.from_stl(FILE)

    # ==============================================================================
    # Create planes
    # ==============================================================================

    # replace by planes along a curve

    bbox = benchy.bounding_box()

    x, y, z = zip(*bbox)
    zmin, zmax = min(z), max(z)

    normal = Vector(0, 0, 1)
    planes = []
    for i in np.linspace(zmin, zmax, 50):
        plane = Plane(Point(0, 0, i), normal)
        planes.append(plane)



    # ==============================================================================
    # Slice
    # ==============================================================================

    M = benchy.to_vertices_and_faces()


    pointsets = slicer.slice_meshPython(M, planes)


    # ==============================================================================
    # Process output
    # ==============================================================================

    polylines = []
    for points in pointsets:
        points = [Point(*point) for point in points]
        print(points[0])
        polyline = Polyline(points)
        polylines.append(polyline)
    print(len(polylines))

    print("End")


test_slicer()
